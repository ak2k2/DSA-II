# Make/Run
- ➜  kapoor_spell_check ✗ make
- ➜  kapoor_spell_check ✗ ./main

# Files
- Enter the name of the dictionary file: wordlist_small.txt (./data/{path_to_dictionary_file})
- Enter the name of the document file to be spell-checked: input.txt (./data/{path_to_document_to_be_spell_checked})
- Enter the name of the output file: output.txt (./data/{path_to_output_file})

# Output
- ➜  kapoor_spell_check ✗ cat data/output.txt